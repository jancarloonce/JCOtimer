Just use the import  statement:
from JCOtimer.timer import timer