This package is for measuring the time spent for a function to run.

Just use the import  statement:

from JCOtimer.timer import timer